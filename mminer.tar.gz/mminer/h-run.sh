#!/usr/bin/env bash

. h-manifest.conf

conf=`cat $MINER_CONFIG_FILENAME`

echo $conf

if [[ $conf=~';' ]]; then
    conf=`echo $conf | tr -d '\'`
fi

eval "unbuffer ./mminer ${conf//;/'\;'}"
