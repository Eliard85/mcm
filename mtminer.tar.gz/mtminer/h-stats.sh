#!/usr/bin/env bash

# Load miner JSON stats
stats=$(cat /var/run/hive-miner-bteminer.stats.json 2>/dev/null)

# Extract total hashrate in khs
khs=$(echo "$stats" | jq '[.hs[]] | add / 1000' 2>/dev/null)

# Fallback to 0 if not set
khs=${khs:-0}

local temp=$(jq '.temp' <<< $gpu_stats)
local fan=$(jq '.fan' <<< $gpu_stats)

stats=$(echo "$stats" | jq --argjson temp "$temp" --argjson fan "$fan" '
  .temp = $temp | .fan = $fan
')

#echo $stats
#echo $khs
#echo $temp
#echo $fan