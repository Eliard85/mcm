#!/bin/bash
set -e

# Функция для получения установленной версии Java
get_java_version() {
  if ! command -v java &> /dev/null; then
    echo "0"
  else
    java -version 2>&1 | awk -F[\".] '/version/ {print $2}'
  fi
}

# Получаем версию
java_ver=$(get_java_version)

# Проверяем версию
if [[ "$java_ver" -lt 17 ]]; then
  echo "Устанавливается OpenJDK 17..."
  sudo apt update
  sudo apt install -y openjdk-17-jre-headless
else
  echo "Java версии $java_ver уже установлена, установка не требуется."
fi

